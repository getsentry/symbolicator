'use strict';;!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2f259f80-58b7-44cb-d7cd-de1505e7e718",e._sentryDebugIdIdentifier="sentry-dbid-2f259f80-58b7-44cb-d7cd-de1505e7e718")}catch(e){}}();

Object.defineProperty(exports, '__esModule', { value: true });

var Sentry = require('@sentry/node');

function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  var n = Object.create(null);
  if (e) {
    Object.keys(e).forEach(function (k) {
      if (k !== 'default') {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () { return e[k]; }
        });
      }
    });
  }
  n["default"] = e;
  return Object.freeze(n);
}

var Sentry__namespace = /*#__PURE__*/_interopNamespace(Sentry);

// This const is used for nothing except to make this file identifiable via its content.
// We search for "_sentry_release_injection_file" in the plugin to determine for sure that the file we look at is the release injection file.

// _sentry_release_injection_file

    var _global =
      typeof window !== 'undefined' ?
        window :
        typeof global !== 'undefined' ?
          global :
          typeof self !== 'undefined' ?
            self :
            {};

    _global.SENTRY_RELEASE={id:"0.0.1"};

function getGlobal() {
  return global.SENTRY_RELEASE;
}

function helloWorld() {
  console.log("Hello world!");
}

console.log("entrypoint1.js loaded");

function main() {
  console.log("called main (entrypoint1.js)");
  helloWorld();
}

// TEST

console.log("global:", getGlobal());

Sentry__namespace.init({
  dsn: "https://5ca6c435afc347aaa9a5e6fe9113c11f@o1163812.ingest.sentry.io/6762530",

  // We recommend adjusting this value in production, or using tracesSampler
  // for finer control
  tracesSampleRate: 1.0,
  debug: true,
  integrations: () => [],
});

// asdfaf
Sentry__namespace.captureException(new Error("Errör"));

exports.getGlobal = getGlobal;
exports.main = main;
//# sourceMappingURL=entrypoint1.js.map

//# debugId=2f259f80-58b7-44cb-d7cd-de1505e7e718